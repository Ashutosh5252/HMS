# Hostel
This is hostel management website.In this Warden and Hostel Manager can distribute notice to hosteller and Hostel Manager can view The status of Hostel Rooms.
